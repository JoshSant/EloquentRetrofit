<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCocheTable extends Migration
{
 
    public function up()
    {
        Schema::create('coche', function (Blueprint $table) {
            $table->id(); 
            $table->string('matricula', 12)->unique();
            $table->string('marca', 30);
            $table->string('modelo', 50);
            $table->string('imagen', 120);
            $table->Integer('caballos');
        });
    }

    
    public function down()
    {
        Schema::dropIfExists('coche');
    }
}
